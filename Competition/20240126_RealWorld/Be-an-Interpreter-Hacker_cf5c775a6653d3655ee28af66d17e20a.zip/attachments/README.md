# README

## Build

```
docker build -t ghostscript .
```

## Run

```
docker run -it --rm --name ghostscript -p 1337:1337 ghostscript
```