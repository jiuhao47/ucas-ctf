EAT_MESSAGE = ["Yummy!", "Life is uncertain. Eat dessert first.", "I live to eat!", "Time to eat!"]

PWN_SUCCESS_MESSAGE = ["Haaaaacking is so fun!", "My crime is that of curiosity.", "Hacking is not a crime.", "Be a Godlike-level Hacker"]

PWN_FAIL_MESSAGE = ["hmm... tooooo tired today..", "I need a rest", "I don't want to study today"]

SLEEP_MESSAGE = ["So sweet", "Good night, good dream", "Happiness is a nice long nap", "When I wake up, I am reborn."]

DATE_REQUEST_MESSAGE = [
    "Shall we register CODEGATE 2024?",
    "Let's learn buffer overflow!",
    "Let's learn about cryptography!",
    "Shall we contribute to open-source projects?",
    "Would you like to develop a mobile app?",
    "Would you like to participate in a bug bounty program?",
    "Shall we organize a tech meetup?",
    "Let's learn about format string vulnerabilities!",
    "How about a weekend hackathon?",
    "Let's learn about shellcode injection!",
    "Shall we explore new programming languages?",
    "Let's learn about integer overflows!",
    "Would you like to participate in a coding bootcamp?",
    "Let's learn about cross-site scripting!",
    "Shall we read a book on software engineering?",
    "Let's learn about directory traversal!",
    "How about we develop an app together?",
    "Let's learn about SQL injection!",
    "Shall we work on our coding skills this summer?",
    "Let's learn about code injection!",
    "Would you like to write a research paper on cybersecurity?",
    "Let's learn about fuzz testing!",
    "Shall we attend a machine learning workshop?",
    "Let's learn about side-channel attacks!",
    "How about we join a startup incubator?",
    "Let's learn about malware analysis!",
    "Shall we build a home automation system?",
    "Let's learn about network sniffing!",
    "Let's learn about man-in-the-middle attacks!",
    "Shall we study quantum computing?",
    "Let's learn about password cracking!",
    "Would you like to participate in a bug bounty program?",
    "Let's learn about sandbox evasion!",
    "Would you like to go DEF CON Conference together?",
]

DATE_SUCCESS_MESSAGE = ["Yes, I love it!", "With pleasure.", "Whatever you want.", "How can I say no to you?"]

DATE_FAIL_MESSAGE = ["Sorry, I'm tired today.", "...(No response at all...)", "Go away", "Umm.. Maybe another time."]
